
import axios from "axios";
import apitools from "./api"

const mapMixin = {
    methods: {
        getMap() {
            this.mapCreator = apitools.MAP_API
        },
        async getEarthquakeDatas() {
            let earthquakeDatas = await axios.get(apitools.EARTHQUAKE_API)
            let earthquakeResults = await earthquakeDatas.data.result
            return earthquakeResults
        },
        createMarkerDatas() {
            this.getEAdatas.then((res) => {
                res.map((item) => {
                    this.position.push({
                        position: { lat: item.geojson.coordinates[1], lng: item.geojson.coordinates[0] }
                    }
                    )
                    this.getHeatMapDatas.push({ lat: item.geojson.coordinates[1], lng: item.geojson.coordinates[0] })
                })
            })
        },
        createHeatMapDatas() {
            this.position.map((item) => {
                this.getHeatMapDatas.push(item.position)
            })
        },
        
    },
    mounted() {
        this.getMap()
        this.getEarthquakeDatas()
    },
    data() {
        return {
            mapCreator: null,
            earthquakeDatas: {},
            earthquakeResults: [],
            position: [],
            getEAdatas: [],
            getHeatMapDatas: [],
        }
    }
}
export default mapMixin