<template>
  <div id="app">
    <div id="sideBar"></div>
    <div id="mapBox">
      <l-map :zoom="zoom" :center="center" :min-zoom="minZoom" :max-zoom="maxZoom" ref="map">
        <l-tile-layer :url="this.mapCreator" :attribution="attribution" />
        <Vue2LeafletHeatmap :lat-lng="getHeatMapDatas" :radius="40" :min-opacity="0.35" :max-zoom="10" :blur="50">
        </Vue2LeafletHeatmap>
        <v-marker-cluster :options="{ maxClusterRadius: 50 }">
          <l-marker v-for="(item, index) in position" :key="index" :lat-lng="item.position"
            @click="setCenterByLocation(item)" />
        </v-marker-cluster>
        <l-icon-default :image-path="path" />
      </l-map>
    </div>
  </div>
</template>

<script>
import { LMap, LTileLayer, LMarker, LIconDefault } from "vue2-leaflet";
import Vue2LeafletMarkerCluster from 'vue2-leaflet-markercluster'
import mapMixin from "./assets/js/map.js"
import Vue2LeafletHeatmap from "./Vue2LeafletHeatMap";
export default {
  name: "EarthquakeMap",
  mixins: [mapMixin],
  components: {
    LMap,
    LTileLayer,
    LMarker,
    LIconDefault,
    'v-marker-cluster': Vue2LeafletMarkerCluster,
    Vue2LeafletHeatmap,
  },
  data() {
    return {
      zoom: 5,
      minZoom: 5,
      maxZoom: 10,
      path: "/images/",
      center: [38.837033, 35.057786],
      attribution:
        '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',

    };
  },
  mounted() {
    this.getMap()
    this.getEAdatas = this.getEarthquakeDatas()

    setTimeout(() => {
      this.createHeatMapDatas()
      this.createMarkerDatas()
    }, 400);
    setTimeout(() => {
      this.$refs.map.mapObject.setZoom(6)
    }, 200);
  },
  created() {

  },
  methods: {
    setCenterByLocation(location) {
      this.center = [location.position.lat, location.position.lng]

      setTimeout(async () => {
        this.getHeatMapDatas = []
        await this.$refs.map.mapObject.flyTo(this.center, 10, { duration: 0.7 })
      }, 10);
      setTimeout(async () => {
        await this.createHeatMapDatas()
      }, 20);
    }
  }
};


</script>

<style>
@import "~leaflet.markercluster/dist/MarkerCluster.css";
@import "~leaflet.markercluster/dist/MarkerCluster.Default.css";

* {
  margin: 0;
  padding: 0;
}

html,
body {
  height: 100%;
  width: 100%;
}

#app {
  height: 100%;
  width: 100%;
  display: flex;
}

#mapBox {
  height: 100%;
  width: 70%;
}

#sideBar {
  width: 30%;
}

.leaflet-tile-pane {
  filter: brightness(0.6) invert(1) contrast(3) hue-rotate(200deg) saturate(0.3) brightness(0.7);
}
</style>
